# Home Modifications Directory Of Maryland

![](images/b3946c760976cf9a93987d8d929d86c72f47ae858fc49557ad0712f9ebf3209d.jpg)

# Maryland Assistive Technology Program, Maryland Department of Disabilities

The Home Modifications Resource Guide is a publication of the Maryland Department of Disabilities, Assistive Technology Program (MDTAP). This publication was made possible by Grant Number 90AG0006-01-00 from the Administration for Community Living. MDTAP is governed under the provisions of Public Law 108-364, and is provided as a cooperative service of the Department of Disabilities. MDTAP provides information on available products, devices, services and other resources to assist individuals with disabilities. No endorsements of these products, devices, services or resources are intended.

# This publication is available in alternative formats upon request.

# Table of Contents

Funding for Home Modifications   
Tax Benefits… 4-5 Federal and State Financing .5-6 Maryland Centers for Independent Living 6 Web Resources .6 Correction Page.   
Index… .8

# Funding Home Modifications

Most people pay privately for home modifications, but some sources can help you pay for home modification and repairs. This guide includes information on loans (which must be paid back to the lending institutions), grants (money provided for free), and labor organizations that provide the materials, construction, and labor to build or conduct the home modifications at no cost to the consumer.

# Tax Benefits

# Federal

You can deduct the cost of home modifications on your federal income tax if they are medically necessary. You need a written recommendation from a doctor to prove the expense is needed due to a disability or medical condition for yourself, a spouse or a dependent. If a medically necessary home modification does not increase the value of your property, you can deduct the full cost. If it adds value to your property, you can deduct the differences between the cost of the modifications and the value it adds to the property.

#

Maryland Independent Living Tax Credit -

The Maryland Department of Housing and Community Development administers a State of Maryland tax credit for residents of the state who have renovated a home to be more accessible. The tax credit may be up to $50 \%$ of the cost of the renovation up to $\$ 5,000$ , whether it’s your own home, the home of a family member, or a rental property.

# Local

Howard County Government Livable Homes Tax Credit Program is available to Howard County Residents who are owners of real property. These residents are eligible to apply for credit for approved modifications to their homes. Examples of approved modifications include ramps, stair glides, and modifications to doorways and bathrooms.

# ADA Tax Credit for Businesses

A special tax credit is available to help smaller employers make accommodations required by the ADA. More details and appropriate forms can be found online at the IRS website.

# Resources on the Web

NOTE: if you do not have Internet access, you may request copies of these materials from Maryland TAP at 1-800-832-4827 (voice/TTY).

“How to Build Wheelchair Ramps for Home” is a manual of design and construction for modular wheelchair ramps. This manual includes information about ramps and longtread low-riser steps to improve safe home accessibility. The manual is available through the Metropolitan Center for Independent Living for $\$ 15.00$ . Videos are also available on accessible building. For ordering information, please call 651-603-2029. Web site: http://www.klownwerkz.com/ramp/default.htm

The Center for Universal Design is a national center that evaluates, develops and promotes accessible design in building and related products. Website: www.ncsu.edu/ncsu/design/cud/about_ud/udprinciples.htm

# Correction Page

We have supplied a correction page in an attempt to catch any mistakes that may have slipped by our editors, and to note changes in information for our next update to this Directory. Please fax or mail any changes or corrections to us using this sheet. Thank you!

Name: Address: Telephone

Page Were Correction/Change is needed:

Corrected Information:

Please fax to: 410-554-9237

E-Mail: mdtap.general@maryland.gov

Or mail to: Maryland Assistive Technology Program Workforce and Technology Center 2301 Argonne Drive, Room T-42 Baltimore, MD 21218

# INDEX

Federal and State Financing   
Equipment Supplies 10-14   
Funding Sources and Loans Program… . 15-21   
Home Assessment/Equipment Evaluation . 22-26   
Information and Referral 27-29   
Licensed Home Improvement Contractors.. . 30-40   
Volunteer Organization .41-45

# FEDERAL & STATE FINANCING

# Federal Resources

Community Development Block Grant (CDBG) Program

The CDBG program provides annual grants on a formula basis to entitled cities,   
urban counties and states to develop viable urban communities by providing   
decent housing and a suitable living environment, and by expanding economic   
opportunities, principally for low- and moderate-income persons. Some local   
housing agencies utilize portions of their CDBG program to pay for various kinds   
of home modifications. To contact your local CDBG grantee, call the US   
Department of Housing and Urban Development at (202) 708-1112, or visit:   
www.hud.gov/local/md/community/cdbg/index.cfm or   
www.usc.edu/dept/gero/nrcshhm/directory/md.htm

# HOME

HOME provides formula grants to States and localities that communities use— often in partnership with local nonprofit groups—to fund a wide range of activities that build, buy, and/or rehabilitate affordable housing for rent or homeownership or provide direct rental assistance to low-income people. For more information visit: www.hud.gov/offices/cpd/affordablehousing/programs/home

# State Resources

# Maryland WholeHome

The Maryland Department of Housing and Community Development (DHCD) offers loans for home modifications. The purpose of the Maryland WholeHome Program is to preserve and improve single-family properties by providing access to funding to correct exterior and interior deficiencies; make modifications for increased home accessibility (grab bars, ramps, etc.); correct health and safety violations; improve weatherization and energy conservation; and correct leadbased paint violations. For more information contact: 1-800-638-7781.

# Accessible Homes for Seniors

The Maryland Department of Housing and Community Development (DHCD), in partnership with the Maryland Department of Aging (MDoA), coordinated a project to promote accessibility related improvements to the homes of seniors, allowing seniors to remain in their homes and maintain independence. The program provides zero percent interest, deferred loans for a term of 30 years to finance accessibility improvements. The program is available throughout the State and marketed through the Area Agencies on Aging.

# Maryland Medicaid Waivers

Most states offer Medicaid programs that cover home modifications to enable elderly and / or individuals with disabilities to remain living at home. Some waivers pay for assistive technologies such as special equipment for a washroom and adaptive lighting. Other waivers pay for physical modifications to the home, such as the addition of wheelchair ramps, stairlifts, and walk-in or wheelchair accessible bathtubs and showers. These modifications are more formally referred to as Environmental Accessibility Adaptations. Please note, unlike nursing home Medicaid, waivers are not an entitlement. (An entitlement means that anyone eligible will receive care). Typically, waiver programs have limited participant enrollment. And sometimes waiting lists exist for services. For a complete list of Medicaid Waivers in Maryland that include home modifications, click here.

# HomeAbility

HomeAbility is a special product designed to assist Maryland homebuyers with disabilities to finance their home purchase. This loan product is made available through the Maryland Department of Housing and Community Development.

# Centers for Independent Living

Maryland Centers for Independent Living can help you get the resources you need for home modifications. There are seven centers in Maryland:

IMAGE Center 410-982-6311 serves Baltimore City, Baltimore County, and Harford County;   
 Independence Now serves Prince George’s and Montgomery, 301-277- 2839;   
 Resources for Independence, 301-784-1774, serves Garrett, Allegany, and Washington Counties; Freedom Center, 301-846-7811, serves Frederick and Carroll Counties; Southern Maryland Center for Independent Living, 301-884-4498, serving St. Mary’s, Calvert and Charles Counties; Bay Area CIL serving all 8 counties on the Eastern Shore from Somerset to Kent; and Accessible Resources for Independence, (410) 636-2274 serves Anne Arundel and Howard Counties.

# EQUIPMENT SUPPLIES

Accessible Living, A Division of Metropolitan Bath and Tile 6806 Laurel Bowie Rd.   
Bowie, MD 20715   
Phone: 301-835-1736   
Email: bowie@metrobath.com   
Website: https://metrobathandtile.com/accessible-living/   
Description: Home Modifications, Accessible Living, Aging in Place, Barrier Free Bathrooms, Roll-In Showers, Universal Design Kitchens, Universal Design Bathrooms, Ceiling Lifts & Ceiling Tracking Systems, Stair Lifts/Glides, Platform Lifts, Wheelchair Lifts, Automated Door Opening Systems, Grab Bars, Ramps, Lighting, Handrails, Decks, Widen Doorways, Widen Hallways, Relocate   
Switches, Medi-Tubs, Walk-in Tubs, Residential Elevators, etc. MHIC #129895 Type: Equipment Supplies   
Counties: Howard, Montgomery, Prince George’s, Anne Arundel, Baltimore, Carroll, Frederick, Harford, Queen Anne’s, Talbot, Calvert, Charles American Medical Equipment   
733 Fredrick Road   
Catonsville, MD 21228   
Phone: 410-719-1222   
Fax: 410-719-6676   
Website: www.amedeq.com   
Description: Specializes in sales and installation of stair lifts/glides. Also sells and installs modular ramps and sells portable ramps.   
Type: Equipment Supplies   
Counties: All Maryland Counties Area Access- Manassas   
7131 Gateway Ct. Manassas, VA 20109   
Phone: 703-396-4949 or 1-800-333-2732   
Fax: 703-396-4950   
Website: www.areaaccess.com   
Description: Mobility equipment supplier and installer, including residential elevators, stair lifts, lift chairs. Licensed by the MHIC.   
Type: Equipment Supplies   
Counties: All Maryland Counties

Area Access- Richmond 2207 Tazewell Street, Richmond VA. 23222 Phone: 804-355-7102 Website: www.areaaccess.com

Description: Mobility equipment supplier and installer, including residential elevators, stair lifts, lift chairs. Licensed by the MHIC.   
Type: Equipment Supplies   
Counties: All Maryland Counties Area Access- Norfolk   
2812 Cromwell Drive, Norfolk VA.23509   
Phone: 757-852-2732   
Website: www.areaaccess.com   
Description: Mobility equipment supplier and installer, including residential elevators, stair lifts, lift chairs. Licensed by the MHIC.   
Type: Equipment Supplies   
Counties: All Maryland Counties Bedco Mobility, Inc.   
6300 Falls Road, Unit 2, Baltimore, MD 21209   
Phone: 410-825-1440   
Email: info@bedcomobility.com   
Website: https://www.bedcomobility.com   
Description: Install and service accessibility equipment including residential stairlifts, wheelchair lifts, home elevators, adaptive driving aids such as hand controls, spinner knobs and left foot accelerators, van and scooter lifts. They also sell and rent wheelchair accessible vans.

Type: Equipment Supplies Counties: All Maryland Counties

NuMotion   
2700 Lord Baltimore Drive, Baltimore, MD 21244   
Phone: 410-298-4555 or 800-777-6981   
Fax: 410-298-1642   
Website: https://www.numotion.com/locations/baltimore-md   
Description: Custom rehab equipment   
Type: Equipment Supplies   
Counties: All Maryland Counties

# Choice Marketing & Sales, Inc.

1393 Tanyard LN Pasadena, Maryland 21122 Phone: 1-888-761-8780 or 410-761-8787 Fax: 410-437-8077 E-Mail: choicedisabilities@verizon.net

Description: Stair and vehicle lifts, equipment evaluation and repair, home   
assessment and renovations, vehicle sales   
Type: Equipment Supplies   
Counties: All Maryland Counties RCM   
965 Baltimore Annapolis Blvd   
P.O. Box 1199   
Severna Park, Maryland 21146   
Phone: 888-353-8878   
Fax: 410-544-1137   
Website: https://rcmelevators.com/   
Description: Installation and maintenance of elevators, stair/chair lifts, and other durable medical equipment.   
Type: Equipment Supplies   
Counties: All Maryland Counties The Scooter Shop   
6360 South Hanover Rd. Suite B   
Elkridge, MD 21075   
Phone: 877-224-2294 or 443-832-0069   
E-Mail: jim@yourscootershop.com   
Website: www.yourscootershop.com   
Description: Sells and services durable medical equipment.   
Type: Durable Medical Equipment Supplier   
Counties: Baltimore City, Baltimore County, Howard County, Anne Arundel County, Carroll County, Montgomery County, Harford County, Cecil   
County, Prince George’s County, Maryland, and Washington DC.

# Atlantic Door Control/ASSA ABLOY

9550 Berger Road   
Columbia, MD 21046-1513   
Phone: 410-290-9500 or 800-899-2324   
Fax: 410-290-9575 (Sales & Administration) or 410-290-8775 (Service Division) Website: www.atlanticdoorcontrol.com   
Description: An international company that sells commercial and residential automatic sliding doors, apartment doors, swinger doors, etc.   
Type: Equipment Supplies   
Counties: International Frederick, MD. 21703   
Phone: 240-490-7840   
Website: www.tmservices.com   
Description: New, used and rental wheelchair vans, adapted driving equipment, high tech driving equipment, sales & service, ramps, elevators, ceiling lifts, mobility products.   
Type: Equipment Supplies   
Counties: Frederick, Montgomery, Washington, Carroll, Prince George’s USA Rehab   
105 Sudbrook Ln. Suite 107   
Pikesville, MD 21208   
Phone: 410-653-3903   
Fax: 410-653-6996   
E-mail: shara@usa-rehab.com   
Website: www.usa-rehab.com   
Description: Rents and sells modular ramps, portable lifts, grab bars, etc. Type: Durable Medical Equipment Supplier   
Counties: All Maryland Counties

# FUNDING SOURCES AND LOAN PROGRAMS

# Assistive Technology Financial Loan Program

MDTAP   
2301 Argonne Drive, Room T-42   
Baltimore, MD 21218   
Phone: 410-554-9230 or 1-800-832-4827   
TTY: 1-866-881-7488   
Fax: 410-554-9237   
E-Mail: mdtap.atlp@maryland.gov   
Website: www.mdtap.org   
Description: Aids Maryland residents with disabilities and their families in qualifying for low-interest loans to purchase assistive technology. No fee to apply for a loan.   
Type: Funding Sources and Loan Programs   
Counties: All Maryland Counties

# BCAUSE, Baltimore County Age Friendly Upgrades

400 Washington Avenue   
Baltimore, MD 21204   
Phone: 410-887-2109   
E-Mail: afbc@baltimorecountymd.gov   
Website: https://www.baltimorecountymd.gov/departments/aging/programsservices/age-friendly   
Description: Baltimore County Age-Friendly Upgrades for Seniors, BCAUSE, helps seniors over the age of 65 remain in their homes as they age. To be eligible for the program, a person needs to be a Baltimore County homeowner who is 65 years or older and is at or below 50 percent of area median income. Type: Funding Sources and Loan Programs   
Area: Baltimore County CHAI: Comprehensive Housing Assistance, Inc.   
5809 Park Heights Avenue   
Baltimore, MD 21215   
Phone: 410-500-5300   
Fax: 410-466-1996   
E-Mail: info@chaibaltimore.org   
Website: www.chaibaltimore.org   
Description: Provides loans and grants to low and moderate income seniors $6 2 +$ and individuals with disabilities for home repairs, modifications and safety and OT evaluations. Services limited to Northern Park Heights neighborhoods in the 21215 zip code.   
Type: Funding Sources and Loan Programs

Area: Neighborhoods of Falstaff, Glen, Mt. Washington, Cross Country, Pikesville, Randallstown and Cheswolde

# Centers for Independent Living

7 CILs serving all counties in Maryland   
Website: https://www.ilru.org/projects/cil-net/cil-center-and-association-directoryresults/MD   
Description: The CILs across Maryland provide assistive technology matching grants to help fund the cost assistive technology, including the cost related to home modifications for accessibility. Amount of grant varies amongst each CIL. Type: Funding Sources and Loan Programs   
Area: All Maryland Counties

# Developmental Disabilities Administration (DDA) – Main Branch

201 W Preston Street, Suite 422 $4 ^ { \mathrm { t h } }$ Floor   
Baltimore, MD 21201   
Phone: 410-767-5600   
Fax: 410-767-5850   
Website: dda.health.maryland.gov   
Description: The Developmental Disabilities Administration funds a variety of services for people who have developmental disabilities, including determining eligibility for services and medical waivers. Some services and waivers include funding home modifications and assistive technology. See branch information below.

Type: Funding Sources and Loan Programs

# DDA - Central Maryland

Maryland Department of Health and Mental Hygiene   
Central Maryland Regional Office   
1401 Severn St.   
Baltimore, MD 21230   
Phone: 410-234-8200 or 1-877-874-2494   
TTY: 1-800-735-2258   
Fax: 410-234-8397   
Email: bianca.renwick@maryland.gov   
Counties: Anne Arundel, Howard, Harford, Baltimore County, and Baltimore City

# DDA - Eastern Shore

Maryland Department of Health and Mental Hygiene   
Eastern Regional Office   
926 Snow Hill RD   
Salisbury, MD 21804   
Phone: 410-572-5920 or 1-888-219-0478   
TTY: 1-800-735-2258   
Email: rachel.white@maryland.gov   
Counties: Caroline, Cecil, Dorchester, Worcester, Wicomico, Talbot, Somerset,   
Queen Anne's, and Kent   
DDA - Southern Maryland   
Maryland Department of Health and Mental Hygiene   
Southern Maryland Regional Office   
312 Marshall Ave., 7th Floor   
Laurel, MD 20707   
Phone: 301-362-5100 or 1-888-207-2479   
TTY: 301-362-5131   
Email: michael.bryan@maryland.gov   
Counties: Calvert, Charles, St. Mary's, Prince George's, and Montgomery

# DDA - Western Maryland

Maryland Department of Health and Mental Hygiene   
Western Maryland Regional Office   
1360 Marshall St.   
Hagerstown, MD 21740   
Phone: 301-791-4670 or 1-888-791-0193, 1800-735-2258 (240) 313-3869 Fax: 301-791-4019   
Email: Linda.yale@maryland.gov.   
Counties: Allegany, Carroll, Frederick, Garrett, Washington

# Division of Rehabilitation Services (DORS)

Maryland State Dept. of Education   
2301 Argonne Drive   
Baltimore, MD 21218   
Phone: 410-554-9442 or 1-800-479-8613   
TTY: 410-554-9411   
Fax: 410-554-9222   
Email: dors@msde.state.md.us   
Website: www.dors.state.md.us

Description: DORS administers vocational rehabilitation in Maryland for people with disabilities. This program provides rehabilitation services to eligible individuals with the goal of employment. The Independent Living program serves a small number of eligible individuals whose goal is increased independence in their living arrangements. DORS provides funding for home assessments and modifications in some cases, as well as equipment evaluations. Sliding scale fees. Require documentation of financial need. Individuals with higher incomes may be required to pay some of the costs, but many pay nothing. Other possible funding sources must be explored. Ages $1 6 \&$ up.

# Type: Funding Sources and Loan Programs; Home Assessment / Equipment Evaluation Counties: All Maryland Counties

Eric Fund, The   
P.O. Box 65188   
Washington, DC 20035-5188   
Phone: 202-841-2700   
E-Mail: info@ericfund.org   
Website: www.ericfund.org

Description: The Eric Fund, a Washington, DC-based nonprofit, was established in memory of Eric C. Savader, a disability rights advocate who died of cancer in 1997. The goal of the Eric Fund is to help children and adults with disabilities in the Washington, DC, metropolitan area lead more independent, productive lives by purchasing assistive technology not covered by insurance or other funding streams. Twice annually the Eric Fund awards grants to deserving individuals based on financial need. Each year, the Eric Fund gives away $\$ 10,000$ in assistive technology and living aids for people with disabilities in the Washington, D.C. area including Northern Virginia and Maryland. Type: Funding Sources and Loan Programs

Help Hope Live   
2 Radnor Corporate Center   
100 Matson Ford RD Suite 100   
Radnor, PA 19087   
Phone: 1-800-642-8399   
Website: www.helphopelive.org   
Description: Supports community-based fundraising for people with unmet medical expenses and related costs due to cell and organ transplants or catastrophic injuries and illnesses.   
Type: Funding Sources and Loan Programs   
Counties: All Maryland Counties

HUBS, Housing Upgrades to Benefit Seniors

2701 Saint Lo Drive,   
Baltimore, MD 21213   
Phone: 410-366-8533   
Fax: 410-366-1831   
Email: info@civicworks.com   
Website: https://civicworks.com/programs/housing-upgrades-to-benefit-seniors/ Description: Social Workers and staff members based at each site work with clients one-on-one through assessing their home modification needs and determining other community resources that may improve the quality of their lives.

Loading Dock, The 2 North Kresson Street Baltimore, MD 21224 Phone: 410-558-DOCK (3625) Fax: 410-558-1888 Email: kirkland@loadingdock.org Website: www.loadingdock.org

Description: A 2100 square foot warehouse that acts as a clearinghouse for new and used building materials, which are distributed to families with low incomes and nonprofit agencies. Nominal membership fee, minimal charges for materials.

Referral Required: From Department of Social Services or a nonprofit organization.

Type: Funding Sources and Loan Programs Counties: All Maryland Counties

# Muscular Dystrophy Association

8501 LaSalle Road #106   
Towson, MD 21286   
Phone: 410-494-7106; 1-833-275-6321   
Fax: 410-494-0082   
Website: www.mda.org

Description: Helps pay for occupational therapy (OT) evaluations, which may include recommendations for home modifications. Works with designated occupational therapists. Pays a set amount for one evaluation per person per year; MDA pays up to $\$ 200$ per evaluation. Serves only people with neuromuscular disorders, including muscular dystrophy.

Type: Funding Sources and Loan Programs Counties: All Maryland Counties

# National Multiple Sclerosis Society - Maryland Chapter

2219 York Rd #302,   
Timonium, MD 21093   
Phone: 443-641-1200 or 1-800-FIGHT-MS   
Fax: 443-641-1201   
Email: tod.robertson@nmss.org or info@nmss-md.org   
Website: www.nationalmssociety.org   
Description: The Chapter offers hands-on assistance to people with multiple   
sclerosis who need help navigating the complex federal, state and community

programs available for people with disabilities. Assistance includes area such as services available to help people remain in their homes safely, affordable health insurance options, employment laws, and financial planning and financial assistance resources.

Type: Funding Sources and Loan Programs Counties: All Maryland Counties

# Rural Development Administration - Maryland and Delaware State Office

USDA Rural Development   
Maryland/Delaware State Office   
1221 College Park Drive, Suite 200, Dover, DE 19904   
Phone: 302-857-3581   
Fax: 855-389-2241   
Contact: David Baker, State Director   
Email: David.Baker3@usda.gov   
Website: https://www.rd.usda.gov/de_md

Description: 504 Loan and Grant program provides $1 \%$ loans up to a maximum of $\$ 20,000$ per loan to homeowners of any age who live in rural areas and have very low incomes. Sometimes have funds available for grants of up to $\$ 7,500$ for rural homeowners who are 62 and older and have very low incomes. Loans and grants may be used for home modifications, purchases, and repairs. To qualify for loans, must be unable to obtain a commercial loan, have good credit and be able to repay the loan. Both programs are limited to rural areas.

Type: Funding Sources and Loan Programs Counties: All Maryland Counties

# Specially Adapted Housing for Disabled Veterans

Department of Veterans Affairs, Veterans Affairs Regional Office, 31 Hopkins Plaza, Rm 3020 Baltimore, MD 21201   
Phone: 410-230-4444   
Toll free: 800-446-4926   
Fax: 410-203-4445   
Website: https://www.va.gov/housing-assistance/disability-housing-grants Description: Assists certain disabled veterans and retired military personnel in acquiring suitable housing units, with adapted features. Can assist in financing new construction or remodeling, or applications against an outstanding mortgage on a specially adapted home. The disability must be service connected and fall within a set of specified parameters, which includes mobility impairment.   
Please call the VA before buying a house so they can examine it to see if a grant can be issued for that particular home.

# Travis Roy Foundation

# HOME ASSESSMENT / EQUIPMENT EVALUATION

# Abilities OT & Irlen Diagnostic Center

600 Reisterstown Rd #600GHI, Baltimore, MD 21208 Phone: 410-358-7269 Fax: 443-438-9948 Email: info@aotss.com Website: www.aotss.com

Description: Virtual and onsite home assessments and consultations.

Comprehensive testing for sensory and environmental stressors and physical barriers. Office, home, classroom, and ergonomic assessments. Over 30 years of experience working with clients , caregivers and design/build professionals

Referral: Doctor's referral may be required for certain types of insurance reimbursements for home assessments

Type: Home Assessment / Equipment Evaluation Counties: All Maryland Counties

# Division of Rehabilitation Services (DORS)

Maryland State Dept. of Education   
2301 Argonne Drive   
Baltimore, MD 21218   
Phone: 410-554-9442   
TTY: 1-866-881-7488   
Fax: 410-554-9136   
Email: dors@msde.state.md.us   
Website: www.dors.state.md.us

Description: DORS administers vocational rehabilitation in Maryland for people with disabilities. This program provides rehabilitation services to eligible individuals with the goal of employment. The Independent Living program serves a small number of eligible individuals whose goal is increased independence in their living arrangements. DORS provides funding for home assessments and modifications in some cases, as well as equipment evaluations. Sliding scale fees. Require documentation of financial need. Individuals with higher incomes may be required to pay some of the costs, but many pay nothing. Other possible funding sources must be explored. Ages $1 6 \&$ up.

Type: Funding Sources and Loan Programs; Home Assessment / Equipment   
Evaluation   
Counties: All Maryland Counties

# Easter Seals Delaware & Maryland Eastern Shore

Easter Seal Society for Disabled Children and Adults, Inc. 61 Corporate Commons Blvd. Newcastle DE 19720

Phone: 302-324-4444   
Fax: 302-324-4441   
Website: https://www.easterseals.com/de/

Description: A non-profit health care agency dedicated to increasing the independence of children and adults with disabilities. The Salisbury office is specifically an outpatient pediatric rehabilitation center. The Newcastle location includes an Assistive Technology resource center. All provide information and referral.

Type: Funding Sources and Loan Programs; Information and Referral Counties: Caroline, Cecil, Dorchester, Kent, Queen Anne's, Somerset, Talbot, Wicomico, Worcester

# Federal Home Solutions, Inc.

Phone: 410-409-8128 or 443-324-4419   
Website: www.federalhomesolutions.com   
Email: federalhomesolutions@gmail.com   
Description: Full service custom remodeling company specializing in   
modifications for seniors and people with disabilities.   
Certified Aging in Place Specialist. MHIC licensed.   
Type: Funding Sources and Loan Programs; Information and Referral   
Counties: Baltimore, Carroll, Harford, Howard, Anne Arundel, Montgomery, and Prince Georges

# Glickman Design Build, LLC

15757 Crabbs Branch Way, Rockville, MD 20855   
Phone: 301-444-4663 (MD) or 202-792-7320 (DC)   
Email: Russ@GlickmanDesignBuild.com   
Website: www.GlickmanDesignBuild.com   
Description: Certified in accessibility consultation, design, planning and building. Offers full range of contracting for home modifications including: Design and remodeling kitchens, bathrooms, basements; creative/attractive entryways, expanding doorways; constructing ramps; installing stair glides, lifts, elevators, grab bars and remote door openers. Design/build. Fixed-rates.   
Type: Expert in designing, planning and building any type of home modifications or new custom homes for special needs and aging-in-place. As the parent of a child with cerebral palsy who has lived at home in a wheelchair for over 20 years, Russ Glickman has developed a passion to serve the special needs community. Counties: All Maryland Counties, DC, VA Phone: 301-277-2839   
Fax: 301-625-9777   
Website : www.innow.org   
Email: info@innow.org   
Description:   
Prince George’s County: Operates a project which provides home assessments by an Occupational Therapist and pays for low cost home modifications. Identifies and screens contractors, leverages other resources (volunteer services, etc.) to help fund the balance of the project. Serves people with all disabilities.   
Montgomery County: Provides in-home assessments by an Occupational Therapist for a fee. Both offices provide advocacy for people needing home modifications, including help with securing funding.   
Type: Home Assessment / Equipment Evaluation; Funding Sources and Loan Programs; Information and Referral   
Counties: Montgomery, Prince George's Rehab at Work   
6951 Golden Ring Rd   
Baltimore, MD 21237   
Phone: 888-827-6361 or 410-866-3855   
Website: www.rehabatwork.com   
Description: Provides workplace safety assessments and recommends specific workplace modifications. Onsite workplace assessments, some health insurance policies cover services.   
Type: Workplace Assessment / Equipment Evaluation   
Area: Anne Arundel, Carroll, Charles, Frederick, Montgomery, and Prince George's

# The Right Turn Rehabilitation Services

Abingdon, MD 21009   
Phone: 443-402-5490   
Fax: 443-420-6747   
Email: rightturn324@gmail.com   
Website: www.rightturnrehab.com

Description of Services: Geared toward helping seniors and those with disabilities safely and independently “age in place”. Home modification evaluations offer an in-depth look at the person’s environment, how they function in the environment, and what is needed to safely age in the home. The Right Turn offers detailed recommendations including floor plans and visual aids to effectively communicate the recommended modifications to the client.

Referral: Doctor’s referral may be required for certain types of insurance (Medicare, Medicaid, TRICARE), private pay accepted.

Type: Home Modification evaluations, Equipment evaluations/recommendations, Environmental accessibility adaptations (ramps, stair lifts, grab bars, etc.), Referrals for funding sources and loan programs in Maryland Counties Served: Baltimore city, Harford County, Baltimore County, Cecil County, Howard County, Anne Arundel county

# Strategies for Independent Living, LLC

1007 Elm Avenue   
Tacoma Park, MD 20912   
Phone: 301-585-5738   
Website: www.strategiesforindependentliving.com   
Email: steve@strategiesforindependentliving.com

Description: A design/build construction company specializing in Aging in Place and Universal Design. Helps to facilitate safety and independence for clients by employing a combination of both large and small home modifications. Strategies works with people of all ages and abilities, educating them so they are better equipped to make the decisions that will lead to the best outcomes for their families. Services include design and feasibility evaluations to installing grab bars, railings, ramps, automatic door openers, and remodeling bathrooms and kitchens.

Type: Home Assessment / Equipment Evaluation; Information and Referral Counties: Montgomery, Prince George's, Howard, and Anne Arundel County

USA Rehab   
104 Church Lane Suite 107 Baltimore MD 21208   
Phone: 410-653-3903   
Fax: 410-653-6996   
Email: shara@usa-rehab.com   
Description: a medical equipment supply company providing assistive devices to clients in the residential setting. USA Rehab is also a Maryland licensed contractor specializing in home modifications.   
Type: Home Assessment / Equipment Evaluation/ Environmental Accessibility Adaptations (ramps, lifts, grab bars, door widening, stair rails)   
Counties: Baltimore City, Baltimore, Anne Arundel, Carroll, Harford, Howard, Montgomery, and Prince Georges Counties.

# INFORMATION AND REFERRAL

# Centers for Independent Living

7 CILs serving all counties in Maryland   
Website: https://www.ilru.org/projects/cil-net/cil-center-and-association-directoryresults/MD   
Description: The CILs across Maryland provide assistive technology matching grants to help fund the cost assistive technology, including the cost related to home modifications for accessibility. Amount of grant varies amongst each CIL. Type: Funding Sources and Loan Programs   
Area: All Maryland Counties

# Public Justice Center- Human Right to Housing

201 N Charles St Suite 1200, Baltimore, MD 21201   
Phone: 410-625-9409   
Email: info@publicjustice.org   
Website: http://www.publicjustice.org/en/human-right-to-housing/   
Description: Founded in 1985, the Public Justice Center uses legal tools to challenge poverty and racial inequity in Maryland and Beyond. Defends renters facing eviction and predatory landlord practices, demand repair of unsafe housing conditions, and advocate to change the law regarding evictions and to demand the development of equitable and sustainable affordable housing. Type: Information and referral, legal aid   
Counties: Baltimore City

# Easter Seals Delaware & Maryland Eastern Shore

Easter Seal Society for Disabled Children and Adults, Inc. 61 Corporate Commons Blvd. Newcastle DE 19720   
Phone: 302-324-4444   
Fax: 302-324-4441   
Website: https://www.easterseals.com/de/

Description: A non-profit health care agency dedicated to increasing the independence of children and adults with disabilities. The Salisbury office is specifically an outpatient pediatric rehabilitation center. The Newcastle location includes an Assistive Technology resource center. All provide information and referral.

Type: Funding Sources and Loan Programs; Information and Referral Counties: Caroline, Cecil, Dorchester, Kent, Queen Anne's, Somerset, Talbot, Wicomico, Worcester

Frederick Community Action Agency   
100 South Market Street   
Frederick, MD 21701   
Phone: (301)600-1506   
TTY: 301-662-9164   
Fax: 301-662-9079   
Website: www.cityoffrederickmd.gov   
Description: Offers information and referral for services related to housing and other issues. Can provide some help negotiating the service system (“greasing wheels”). Service area is limited to the City of Frederick.   
Type: Information and Referral   
Counties: Frederick

# Howard County Department of Community Resources and Services - Office on Aging and Independence: Maryland Access Point (MAP)

9830 Patuxent Woods Drive   
Columbia, MD 21046   
Phone: 410-313-1234   
Fax: 410-313-5970   
Website: www.howardcountyaging.org   
Email: map@howardcountymd.gov

Description: Maryland Access Point is Howard County’s Aging and Disability Resource Center. Staff provides information and resource assistance regarding home repairs and modifications to people with disabilities, older adults, caregivers and family members, regardless of income. Grant and loan information is available including the Howard County Livable Homes Tax Credit Program.

Counties: Howard

MDTAP   
2301 Argonne Drive, Room T-42   
Baltimore, MD 21218   
Phone: 410-554-9230 or 1-800-832-4827   
TTY: 1-866-881-7488   
Fax: 410-554-9203   
Email: mdtap.general@maryland.gov   
Description: Offers information and referral about assistive technology, including home modifications. Lends assistive devices for up to 4 weeks at a time.   
Type: Information and Referral   
Counties: All Maryland Counties Saint Ambrose Housing Aid Center   
321 East 25th Street   
Baltimore, MD 21218   
Phone: 410-336-8550   
Fax: 410-366-8795   
Website: https://www.stambros.org/   
Email: intake@stambros.org   
Description: Non-profit neighborhood housing group offers programs including homeownership development, which can provide modifications for homebuyers and renters with disabilities. Provides information and referral.   
Type: Funding Sources and Loan Programs; Information and Referral   
Counties: Baltimore City

# Senior Information and Assistance

Maryland Department of Aging   
301 West Preston Street, Room 1007   
Baltimore, MD 21201   
Phone: 410-767-1100 or 1-800-243-3425   
Fax: 410-333-7943   
Website: http://aging.maryland.gov/   
Description: The Maryland Department of Aging can make referrals to an information and referral center in your locality. Local centers provide information on senior services, programs, and benefits (including home modifications). Type: Information and Referral   
Counties: All Maryland Counties

# LICENSED HOME IMPROVEMENT CONTRACTORS

Mills Creek Builders   
9748 Stephen Decatur Highway, Unit 6   
West Ocean City, MD 21842   
Phone: 410-213-7188   
Fax: 410-213-7820   
Website: https://millscreekbuilders.com/   
Email: krohe@millscreekbuilders.com   
Description: Full range of contracting and remodeling for home modification including kitchen, bathrooms, doorways, constructing ramps/no-step entries, stair lift/elevator installation, stair-light installation, remote/electric door openers, emergency call/response systems, and more.   
Type: Licensed Home Improvement Contractor, Certified Aging-in-Place   
Specialist (CAPS)   
Counties: Somerset, Wicomico, Worcester

# Able Access Sales & Service Corporation

13819 Thornton Mill Rd.   
Sparks, MD 21152   
Phone: 410-771-1558   
Description: Builds and fabricates ramps, decks, handrails, etc to increase home accessibility. Fixed rates.   
Type: Licensed Home Improvement Contractor   
Counties: Baltimore County, Baltimore City, Carol, Harford

# Accessible Living, A Division of Metropolitan Bath and Tile

6806 Laurel Bowie Rd.   
Bowie, MD 20715   
Phone: 301-859-4128   
Email: bowie@metrobath.com   
Website: https://metrobathandtile.com/accessible-living/   
Description: Home Modifications, Accessible Living, Aging in Place, Barrier Free Bathrooms, Roll-In Showers, Universal Design Kitchens, Universal Design Bathrooms, Ceiling Lifts & Ceiling Tracking Systems, Stair Lifts/Glides, Platform Lifts, Wheelchair Lifts, Automated Door Opening Systems, Grab Bars, Ramps, Lighting, Handrails, Decks, Widen Doorways, Widen Hallways, Relocate   
Switches, Medi-Tubs, Walk-in Tubs, Residential Elevators, etc. MHIC #129895 Type: Equipment Supplies   
Counties: Howard, Montgomery, Prince George’s, Anne Arundel, Baltimore, Carroll, Frederick, Harford, Queen Anne’s, Talbot, Calvert, Charles

# All Medical Equipment

Towson Medical Equipment   
1844 E. Joppa Rd   
Baltimore, MD 21234   
2923 Olney Sandy Springs Road   
Olney, MD 20832   
Phone: 410-882-4005 or 1-800-446-1778   
Fax: 410-882-0056   
Website: www.towsonmed.com

Description: Installation and service of stair lifts/ stair glides, vertical lifts, inclined lifts, ceiling tracking systems, ramps, door widening, bathroom modifications, roll-in showers, door-opening systems, door widening, and inhome modifications. Provides medical supplies and medical equipment. Serving all of Maryland since 1989. Medicare approved for the Baltimore Towson Competitive Bid Area.

Type: Licensed Home Improvement Contractor Counties: All Maryland Counties

# American Lift and Elevator

9522 Deereco RD   
Timonium, MD 21093   
Phone: 410-665-5040 Toll free (877)360-6777   
Fax: 405-282-8105   
Email: info@americanliftandelevator.com   
Website: www.americanliftsandremodeling.com   
Description: Offers lift fabrication and home elevator installation. Type: Licensed Home Improvement Contractor   
Counties: Central Maryland CHAI: Comprehensive Housing Assistance, Inc.   
5809 Park Heights Avenue   
Baltimore, MD 21215   
Phone: 410-500-5300   
Fax: 410-466-1996   
Email: info@chaibaltimore.org   
Website: www.chaibaltimore.org   
Description: Provides loans and grants to low and moderate income seniors $6 2 +$ and individuals with disabilities for home repairs, modifications and safety and OT evaluations. Services limited to Northern Park Heights neighborhoods in the 21215 zip code.   
Type: Funding Sources and Loan Programs   
Area: Neighborhoods of Falstaff, Glen, Mt. Washington, Cross Country,   
Pikesville, Randallstown and Cheswolde

Greg Cantori 8293 Shilling Road Pasadena MD 21122 Phone 410-450-4466

Description: MHIC Licensed and Certified Aging in Place Specialists. Expert in providing home modifications for those with temporary and permanent disabilities.

Full-service handyman with a focus on making homes more accessible including expanding doorways; constructing ramps, grab bars, standing poles, extra lighting, modifying beds, and making other often little but vitally important improvements that make a home both safer and more comfortable. We offer a sliding scale for low-income households and assist them in applying for the loans, grants, and tax credits they are eligible for.

Type: Expert in creating nearly every home modification for special needs and aging-in-place. With over 35 years of working in the nonprofit sector helping those with low incomes with their homes, Little Deeds has the skills along with caring deeply with well-earned trust to make a difference

Counties: Anne Arundel, Baltimore, Howard, Montgomery, Prince Georges, and Kent Counties.

# Email American Contracting Services, Inc.

1620 Providence Road   
Towson, MD 21286   
Phone: 410-494-0900   
Website: www.american-contracting.com   
Email: acsi@american-contracting.com

Description: Renovations to homes and businesses to accommodate persons who desire to age in place in their homes or persons with disabilities. Modifications include bathrooms, kitchens, in-law suites, and first floor bedrooms including installing ramps, stair lifts, vertical wheelchair lifts, elevators and ceiling lifts and transport systems to multiple rooms.

Type: Licensed Home Improvement Contractor, MHIC #51879 Counties: Baltimore City, Anne Arundel, Cecil, Montgomery, Howard, Harford, Baltimore County

# Federal Home Solutions, Inc.

Phone: 410-409-8128 or 443-324-4419   
Email: federalhomesolutions@gmail.com   
Description: Full service custom remodeling company specializing in   
modifications for seniors and people with disabilities.   
Certified Aging in Place Specialist. MHIC licensed.   
Type: Funding Sources and Loan Programs; Information and Referral   
Counties: Baltimore, Carroll, Harford, Howard, Anne Arundel, Montgomery, and Prince Georges

# Gladden Construction, Inc.

105 South Division Street   
Fruitland, MD 21826   
Phone: 410-742-1614   
Fax: 410-742-9651   
Website: www.gladdenconstruction.com   
Description: Offers wide range of contracting for home modifications, including remodeling kitchens, bathrooms and doorways; constructing ramps. Some experience installing stair glides, lifts, elevators. Performs all home renovations. Type: Licensed Home Improvement Contractor   
Counties: Dorchester, Somerset, Wicomico, Worcester; Lower Delaware; Lower Virginia

# Glickman Design Build, LLC

15757 Crabbs Branch Way, Rockville, MD 20855   
Phone: 301-444-4663   
VA 703-832-8150   
DC 202-792-7320   
Email: Russ@GlickmanDesignBuild.com   
Website: www.GlickmanDesignBuild.com   
Description: Certified in accessibility consultation, design, planning and building. Offers full range of contracting for home modifications including: Design and remodeling kitchens, bathrooms, basements; creative/attractive entryways, expanding doorways; constructing ramps; installing stair glides, lifts, elevators, grab bars and remote door openers. Design/build. Fixed-rates.   
Type: Expert in designing, planning and building any type of home modifications or new custom homes for special needs and aging-in-place. As the parent of a child with cerebral palsy who has lived at home in a wheelchair for over 20 years, Russ Glickman has developed a passion to serve the special needs community. Counties: All Maryland Counties, D.C., VA

# HandyPro of Delmarva

209 Hess Road   
Grasonville, MD 21638   
Phone: 410-213-3543   
Website: http://delmarva.handypro.com/   
Description: Certified in accessibility consultation, home modifications, and assistive technology. Installation of home accessibility equipment as well as designing and constructing easy living solutions for seniors and families with disabilities.   
Type: Licensed Home Improvement Contractor   
Counties: Caroline, Talbot, Queen Anne, Dorchester, Wicomico, Worcester, Somerset, Anne Arundel, Baltimore County and City, Cecil, and Kent

# HandyPro of Washington DC Metropolitan

10411 Motor city Dr #750   
Bethesda, MD 20817   
Phone: 301-895-7585   
Website: https://www.handypro.com/washington-dc/?L=true

Description: Professional, licensed and certified to do home modifications for people with disabilities. Our services include but are not limited to bathroom conversion, stair lift, ceiling lift, wheelchair lift, ramp, grab bars, automatic door opener, etc.

Type: Licensed Home Improvement Contractor   
Counties: Prince Georges, Montgomery, Carrol, Baltimore, Howard, Anne Arundel.

# Improvement Zone, LLC.

400-B Love Point   
Stevensville, MD 21666   
Phone: 443-221-4661   
Email: info@improvement-zone.com   
Website: www.improvement-zone.com   
Description: Major and minor home repairs, rehabilitation, renovations,   
additions, accessibility modifications   
Type: Licensed Home Improvement Contractor   
Counties: Anne Arundel, Calvert, Prince Georges, Montgomery, Baltimore,   
Baltimore City, Kent, Queen Anne’s and Howard

# INEX Construction, Inc.

636 Blandford Street   
Rockville, MD 20850   
Phone: 301-424-0010   
Email: inex01@verizon.net   
Website: www.inex.us   
Description: Remodeling contractors specializing in ADA installation of bathroom fixtures. Provides complete bathroom and remodeling services. Type: Licensed Home Improvement Contractor   
Counties: Montgomery

Kelly Cove Mobility 2711 Dorr Ave, Suite P Fairfax, VA 22031 Phone: 888-821-0345 Fax: 202-932-7001 Email: support@kellycove.net

Website: www.kellycovemobility.com   
Description: Environmental Modifications, Aging in Place Solutions, Assistive   
Technology, Universal Design   
MHIC Number: 134628   
Type: Licensed Home Improvement Contractor   
Counties: All Maryland Counties (except: Cecil, Dorchester, Kent, Allegany,   
Garrett, Washington, Somerset, Talbot, Wicomico, Worcester)

# Koons Home Improvement

27692 Fairmount Rd.   
Upper Fairmount, MD 21867   
Phone: 410-651-2375   
Description: Offers wide range of contracting for home modifications, including remodeling kitchens, bathrooms and doorways; and constructing ramps. Could also install lifts, stair glides and elevators, but has no experience in this area yet. Fixed rates.

Type: Licensed Home Improvement Contractor Counties: Somerset, Wicomico, and Worchester

# Norino Properties & Construction

Address: 8100 Harford Rd, Parkville, MD 21234   
Phone: 410-663-9444   
Email: norinollc@gmail.com   
Description: General construction that includes automatic door installations. Counties: All Maryland counties

# P.G. Builders

PO Box 505   
Savage, MD 20763   
Phone: 301-346-1902   
Email: bryankebeck@pgbuilders.com   
Website: www.pgbuilders.com   
Description: General construction that includes accessibility and automatic door installations, ADA compliant bathroom renovations and lift and ramp   
construction.   
Counties: All Maryland counties, D.C., and Virginia

# Southern Maryland Home Improvements

5200 Deliverance Place LaPlata, MD 20646 Phone: 301-843-1601

Description: Offers wide range of contracting for home modifications, including remodeling kitchens, bathrooms and doorways, and constructing ramps. Subcontracts out installation of stair glides, lifts, and elevators. Fixed rates. Type: Licensed Home Improvement Contractor   
Counties: Calvert, Charles, and St. Mary's

Stanley D. Groves & Sons, Inc.

1112 Old Westminster Road   
Westminster, MD 21157   
Phone: 410-876-5811, 443-377-7644   
Email: stanleygroves@comcast.net   
Website: https://grovesconcrete.com/   
Description: Specializes in concrete construction. Modifies homes for wheelchair accessibility, ramps, bathrooms, etc.   
Type: Licensed Home Improvement Contractor   
Counties: Carroll, Baltimore, and Fredrick

# Strategies for Independent Living, LLC

1007 Elm Avenue   
Tacoma Park, MD 20912   
Phone: 301-585-5738   
Email: info@strategiesforindependentliving.com   
Website: www.strategiesforindependentliving.com

Description: A design/build construction company specializing in Aging in Place and Universal Design. Helps to facilitate safety and independence for clients by employing a combination of both large and small home modifications. Strategies works with people of all ages and abilities, educating them so they are better equipped to make the decisions that will lead to the best outcomes for their families. Services include design and feasibility evaluations to installing grab bars, railings, ramps, automatic door openers, and remodeling bathrooms and kitchens.

Type: Home Assessment / Equipment Evaluation; Information and Referral Counties: Montgomery, Prince George's, Howard, and Anne Arundel County

# Taylor Made Custom Contracting

1944 Nelson Mill Road   
Jarrettsville, MD 21084   
Phone: 410-557-0322   
Fax: 410-692-2457   
Email: info@taylormadecontracting.com   
Website: www.taylormadecontracting.com Description: Offers wide range of contracting for home modifications, including remodeling kitchens, bathrooms and doorways; constructing ramps.   
Subcontracts out installation of lifts, stair glides and elevators. Fixed rates. Type: Licensed Home Improvement Contractor   
Counties: All Maryland Counties

# All Mobility Solutions

8999 Ocean Highway   
Delmar, MD 21875   
Phone: 410-543-4323   
Fax: 410-912-0401   
Email: ssmith@allmobilitystore.com   
Description: Offers a wide range of mobility equipment, including scooters, ramps, lifts, wheelchairs, and rental mobility vans. As well as servicing all mobility equipment.   
Type: Mobility Company   
Counties: Anne Arundel, Baltimore City, Baltimore County, Calvert, Caroline, Dorchester, Kent, Prince George's, Queen Anne's, Somerset, St. Mary's, Talbot, Wicomico, Worcester, D.C., Virginia

# Walsh Home Improvement Co. Inc

8707 Cypress Ct.   
Berlin, MD 21811   
Phone: 410-641-3762, 301-776-7249   
Fax: 410-641-2296   
Website: http://www.walshhomeimprovementinc.com/   
Description: Offers wide range of home modifications including handicap ramps, stair lifts, grab bars, railings, doorways widened, and more.   
Type: Licensed Home Improvement Contractor   
Counties: Worcester, Wicomico, Dorchester, Somerset, Caroline, Talbot, Queen Anne's, Kent

# VOLUNTEER ORGANIZATIONS

# Homes for our Troops

6 Main Street   
Taunton, MA 02780   
Phone: 508-823-3300 or 866-787-6677   
Email: info@hfotusa.org   
Website: www.hfotusa.org   
Description: Building and donating specially adapted custom homes for severely   
injured veterans post- 9/11   
Counties: All Maryland Counties

# Rebuilding Together - National Office

999 N Capitol St. NE Suite 330 Washington, DC 20002 Phone: 1-800-473-4229 or 202-483-9083 Email: communications@rebuildingtogether.org Website: www.rebuildingtogether.org

Description: A premier nonprofit community revitalization organization with over 120 affiliates across the country. Together, with their corporate and community partners, they repair homes, revitalize communities and rebuild lives. Rebuilding Together affiliates make essential repairs to help neighbors (often older adults, people with disabilities, veterans and families with children) stay in their homes.

Type: Volunteer Organization Counties: All Maryland Counties

# Rebuilding Together - Anne Arundel County

819 Ritchie Highway Suite 2000   
Severna Park, MD 21146   
Phone: 410-923-9992   
Email: information@rebuildingtogetheraac.org   
Website: www.rebuildingtogetheraac.org

Description: A premier nonprofit community revitalization organization with over 120 affiliates across the country. Together, with their corporate and community partners, they repair homes, revitalize communities and rebuild lives. Rebuilding Together affiliates make essential repairs to help neighbors (often older adults, people with disabilities, veterans and families with children) stay in their homes.

Type: Volunteer Organization Counties: Anne Arundel

# Rebuilding Together - Baltimore

5513 York Rd. Baltimore, MD 21212

Phone: 410-889-2710 Fax: 443-586-0785 Email: info@rtbaltimore.org Website: www.rtbaltimore.org

Description: A premier nonprofit community revitalization organization with over 120 affiliates across the country. Together, with their corporate and community partners, they repair homes, revitalize communities and rebuild lives. Rebuilding Together affiliates make essential repairs to help neighbors (often older adults, people with disabilities, veterans and families with children) stay in their homes.

Type: Volunteer Organization Counties: Baltimore County, Baltimore City

# Rebuilding Together - Frederick County

P.O. Box 1822   
Frederick, Maryland 21702   
Phone: 240-415-8728   
Email: rebuildingfrederick@gmail.com   
Website: http://www.rebuildingtogetherfrederick.org/

Description: A premier nonprofit community revitalization organization with over 120 affiliates across the country. Together, with their corporate and community partners, they repair homes, revitalize communities and rebuild lives. Rebuilding Together affiliates make essential repairs to help neighbors (often older adults, people with disabilities, veterans and families with children) stay in their homes.

Type: Volunteer Organization Counties: Frederick

# Rebuilding Together - Howard County

8775 Centre Park Dr. #519   
Columbia, Maryland 21045   
Phone: 410-381-3338   
Website: www.howardcounty.rebuildingtogether.org   
Email: info@rebuildingtogetherhc.org

Description: A premier nonprofit community revitalization organization with over 120 affiliates across the country. Together, with their corporate and community partners, they repair homes, revitalize communities and rebuild lives. Rebuilding Together affiliates make essential repairs to help neighbors (often older adults, people with disabilities, veterans and families with children) stay in their homes.

Type: Volunteer Organization Counties: Howard

P.O. Box 180   
Chestertown, MD 21620   
Phone: 410-708-9936   
Email: info@rebuildingtogetherkcmd.org   
Website: www.rebuildingtogetherkcmd.org   
Description: A premier nonprofit community revitalization organization with over 120 affiliates across the country. Together, with their corporate and community partners, they repair homes, revitalize communities and rebuild lives. Rebuilding Together affiliates make essential repairs to help neighbors (often older adults, people with disabilities, veterans and families with children) stay in their homes.

Type: Volunteer Counties: Kent County

Rebuilding Together - Montgomery County   
18225-A Flower Hill Way   
Gaithersburg, MD 20879   
Phone: 301-947-9400   
Fax: 301-947-9411   
Email: info@rebuildingtogethermc.org   
Website: www.rebuildingtogethermc.org

Description: A premier nonprofit community revitalization organization with over 120 affiliates across the country. Together, with their corporate and community partners, they repair homes, revitalize communities and rebuild lives. Rebuilding Together affiliates make essential repairs to help neighbors (often older adults, people with disabilities, veterans and families with children) stay in their homes.

# Home Modifications Directory For Maryland

Maryland Technology Assistance Program

# This publication is available in alternative formats upon request