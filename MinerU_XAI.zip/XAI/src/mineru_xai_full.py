
import os
import json
import numpy as np
import shap
from lime.lime_tabular import LimeTabularExplainer
import matplotlib.pyplot as plt
from PyPDF2 import PdfReader, PdfWriter
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from io import BytesIO
import re

class MinerUXAIText:
    def __init__(self, input_dir='output', output_dir='xai_outputs/text_full_xai'):
        self.input_dir = input_dir
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def load_data(self, model_path, middle_path=None):
        features = []
        labels = []
        coords = []
        texts = []

        text_map = {}

        # Load text features if available
        if middle_path and os.path.exists(middle_path):
            with open(middle_path, 'r', encoding='utf-8') as tf:
                try:
                    mid_data = json.load(tf)
                    for block in mid_data.get('blocks', []):
                        txt = block.get('text', '')
                        bbox = block.get('box', [0,0,0,0])
                        text_map[tuple(bbox)] = txt
                except:
                    pass

        # Load model detections
        with open(model_path, 'r', encoding='utf-8') as jf:
            data = json.load(jf)
            for page in data:
                for det in page.get('layout_dets', []):
                    poly = det.get('poly', [0,0,0,0])
                    score = det.get('score', 0)
                    label = det.get('category_id', -1)

                    if len(poly) >= 4:
                        x_min = min(poly[0::2])
                        x_max = max(poly[0::2])
                        y_min = min(poly[1::2])
                        y_max = max(poly[1::2])
                    else:
                        x_min = x_max = y_min = y_max = 0

                    # Match text block
                    text_val = ''
                    for box, txt in text_map.items():
                        if abs(box[0]-x_min)<20 and abs(box[1]-y_min)<20:
                            text_val = txt
                            break

                    text_len = len(text_val.split())
                    avg_word_len = np.mean([len(w) for w in text_val.split()]) if text_len>0 else 0
                    has_number = 1 if re.search(r'\d', text_val) else 0

                    features.append([x_min, y_min, x_max, y_max, score, text_len, avg_word_len, has_number])
                    labels.append(label)
                    coords.append((x_min, y_min, x_max, y_max))
                    texts.append(text_val)

        return np.array(features), np.array(labels), coords, texts

    def mock_predict(self, X):
        base_prob = X[:, 4].reshape(-1,1)  # use score as probability seed
        probs = np.hstack([1-base_prob, base_prob])
        return probs

    def run_global_shap(self, X, doc_name, feature_names):
        explainer = shap.Explainer(self.mock_predict, X)
        shap_values = explainer(X)
        plt.title(f'Global SHAP Summary - {doc_name}')
        shap.summary_plot(shap_values[:,:,1], X, feature_names=feature_names, show=False)
        plt.savefig(os.path.join(self.output_dir, f'{doc_name}_global_shap.png'))
        plt.close()
        return shap_values

    def run_local_shap(self, shap_values, X, doc_name, feature_names):
        for i in range(min(20, X.shape[0])):
            shap.plots.waterfall(shap_values[i,:,1], show=False)
            plt.savefig(os.path.join(self.output_dir, f'{doc_name}_detection_{i}_shap.png'))
            plt.close()

    def run_lime(self, X, doc_name, feature_names):
        explainer = LimeTabularExplainer(X, feature_names=feature_names, mode='classification')
        for i in range(min(10, X.shape[0])):
            exp = explainer.explain_instance(X[i], self.mock_predict)
            exp.save_to_file(os.path.join(self.output_dir, f'{doc_name}_detection_{i}_lime.html'))

    def overlay_pdf(self, pdf_path, coords, shap_values, doc_name):
        packet = BytesIO()
        can = canvas.Canvas(packet, pagesize=letter)

        for i, (x_min, y_min, x_max, y_max) in enumerate(coords):
            if i < shap_values.shape[0]:
                importance = float(np.sum(shap_values[i,:,1]))
                can.setStrokeColorRGB(1, 0, 0)
                can.rect(x_min/3, (2200-y_max)/3, (x_max-x_min)/3, (y_max-y_min)/3, fill=0)
                can.drawString(x_min/3, (2200-y_min)/3, f'Imp: {importance:.2f}')

        can.save()
        packet.seek(0)

        reader = PdfReader(pdf_path)
        overlay = PdfReader(packet)
        writer = PdfWriter()

        for page in reader.pages:
            page.merge_page(overlay.pages[0])
            writer.add_page(page)

        output_pdf_path = os.path.join(self.output_dir, f'{doc_name}_xai_overlay.pdf')
        with open(output_pdf_path, 'wb') as f:
            writer.write(f)

    def process_all(self):
        feature_names = ['x_min','y_min','x_max','y_max','score','text_len','avg_word_len','has_number']
        for root, _, files in os.walk(self.input_dir):
            for f in files:
                if f.endswith('_model.json'):
                    doc_name = f.replace('_model.json','')
                    model_path = os.path.join(root, f)
                    middle_path = os.path.join(root, f.replace('_model.json','_middle.json'))
                    pdf_path = os.path.join(root, f.replace('_model.json','_origin.pdf'))

                    if not os.path.exists(pdf_path):
                        continue

                    X, y, coords, texts = self.load_data(model_path, middle_path)
                    if X.shape[0] == 0:
                        continue

                    print(f'Processing {doc_name} with text features...')
                    shap_values = self.run_global_shap(X, doc_name, feature_names)
                    self.run_local_shap(shap_values, X, doc_name, feature_names)
                    self.run_lime(X, doc_name, feature_names)
                    self.overlay_pdf(pdf_path, coords, shap_values.values, doc_name)

if __name__ == '__main__':
    xai = MinerUXAIText()
    xai.process_all()
